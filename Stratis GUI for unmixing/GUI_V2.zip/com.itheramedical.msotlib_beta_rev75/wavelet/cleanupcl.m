function cleanupcl()
