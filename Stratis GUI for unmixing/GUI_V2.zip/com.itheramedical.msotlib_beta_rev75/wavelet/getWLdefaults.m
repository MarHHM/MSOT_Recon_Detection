function par = getWLdefaults

par = struct();
par.wl_name='db6';
par.thres = 0.2;
par.depth_proj = 2;
par.depth_im = 2;
par.Athres = 0.001;
par.Sthres = 0.00;
par.Amat_dir = 'E:\_Amatrices';
